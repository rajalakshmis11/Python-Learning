                 |instance|list    |function|class   
__add__          |        |method  |        |        
__annotations__  |        |        |data    |        
__call__         |        |        |method  |method  
__closure__      |        |        |data    |        
__code__         |        |        |data    |        
__contains__     |        |method  |        |        
__defaults__     |        |        |data    |        
__delitem__      |        |method  |        |        
__dict__         |data    |        |data    |data    
__get__          |        |        |method  |        
__getitem__      |        |method  |        |        
__globals__      |        |        |data    |        
__iadd__         |        |method  |        |        
__imul__         |        |method  |        |        
__iter__         |        |method  |        |        
__kwdefaults__   |        |        |data    |        
__len__          |        |method  |        |        
__module__       |data    |        |data    |data    
__mul__          |        |method  |        |        
__name__         |        |        |data    |data    
__qualname__     |        |        |data    |data    
__reversed__     |        |method  |        |        
__rmul__         |        |method  |        |        
__setitem__      |        |method  |        |        
__weakref__      |data    |        |        |data    
TOTALS           |      25|      34|      34|      28
['attr_list.py', '-']
